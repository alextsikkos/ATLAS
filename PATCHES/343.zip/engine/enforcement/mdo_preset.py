# engine/enforcement/mdo_preset.py

import json
import subprocess
from typing import Any, Dict, Tuple


STANDARD_NAME = "Standard Preset Security Policy"
STRICT_NAME = "Strict Preset Security Policy"


def _run_powershell(script: str) -> Tuple[int, str, str]:
    """
    Runs PowerShell using pwsh (preferred) or powershell.
    Returns (exit_code, stdout, stderr)
    """
    for exe in ("pwsh", "powershell"):
        try:
            p = subprocess.run(
                [exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
                capture_output=True,
                text=True,
                timeout=180,
            )
            return p.returncode, p.stdout.strip(), p.stderr.strip()
        except FileNotFoundError:
            continue

    raise RuntimeError("Neither pwsh nor powershell is available on this system")


def apply_mdo_preset_security_policies(
    tenant: dict,
    mode: str = "report-only",
    level: str = "standard",
) -> Tuple[str, Dict[str, Any]]:
    """
    Enforce or report-only check for MDO Preset Security Policies.

    mode:
      - report-only  (no changes)
      - enforce      (enable policy)

    level:
      - standard
      - strict
    """

    mode = (mode or "report-only").strip().lower()
    level = (level or "standard").strip().lower()
    desired_keyword = "standard" if level == "standard" else "strict"

    exo = tenant.get("exoPowershell") or {}
    if not exo:
        return "ERROR", {"reason": "Missing exoPowershell configuration in tenant JSON"}

    app_id = exo.get("appId")
    thumb = exo.get("certificateThumbprint")
    org = exo.get("organization")

    if not (app_id and thumb and org):
        return "ERROR", {
            "reason": "exoPowershell config incomplete",
            "expected": ["appId", "certificateThumbprint", "organization"],
        }

    # IMPORTANT: ps_script is defined unconditionally (fixes your UnboundLocalError)
    ps_script = f"""
$ErrorActionPreference = "Stop"
Import-Module ExchangeOnlineManagement
Connect-ExchangeOnline -AppId "{app_id}" -CertificateThumbprint "{thumb}" -Organization "{org}" -ShowBanner:$false

function Get-PresetRules {{
  $rules = @()

  try {{
    $rules += Get-EOPProtectionPolicyRule | Select-Object Name,State
  }} catch {{
    $null = $null
  }}

  try {{
    $rules += Get-ATPProtectionPolicyRule | Select-Object Name,State
  }} catch {{
    $null = $null
  }}

  # De-dupe by Name
  $dedup = @{{}}
  foreach ($r in $rules) {{
    if ($r -and $r.Name) {{
      $dedup[$r.Name] = $r
    }}
  }}

  return $dedup.Values
}}

function Get-RuleState($name) {{
  $eop = $null
  $atp = $null

  try {{
    $eop = Get-EOPProtectionPolicyRule -Identity $name | Select-Object -First 1 Name,State
  }} catch {{
    $null = $null
  }}

  try {{
    $atp = Get-ATPProtectionPolicyRule -Identity $name | Select-Object -First 1 Name,State
  }} catch {{
    $null = $null
  }}

  [PSCustomObject]@{{
    name = $name
    eopState = if ($eop) {{ $eop.State.ToString() }} else {{ $null }}
    atpState = if ($atp) {{ $atp.State.ToString() }} else {{ $null }}
  }}
}}

$all = Get-PresetRules

# Rules that look like preset security policies
$preset = $all | Where-Object {{
  $_.Name -match "Preset" -and $_.Name -match "Security"
}}

$keyword = "{desired_keyword}"
$target = $preset | Where-Object {{ $_.Name.ToLower().Contains($keyword) }} | Select-Object -First 1

if (-not $target) {{
  $out = [PSCustomObject]@{{
    mode = "{mode}"
    level = "{level}"
    keyword = $keyword
    error = "No matching preset security policy rule found"
    availableRules = ($preset | Select-Object Name,State)
  }}
  $out | ConvertTo-Json -Compress
  Disconnect-ExchangeOnline -Confirm:$false
  exit
}}

$desiredName = $target.Name
$state = Get-RuleState $desiredName

$eopEnabled = ($state.eopState -eq "Enabled")
$atpEnabled = ($state.atpState -eq "Enabled")
$compliant = $eopEnabled -and $atpEnabled

if ("{mode}" -eq "report-only") {{
  $out = [PSCustomObject]@{{
    mode = "{mode}"
    level = "{level}"
    desired = $desiredName
    current = $state
    compliant = $compliant
    availableRules = ($preset | Select-Object Name,State)
    action = "none"
  }}
  $out | ConvertTo-Json -Compress
  Disconnect-ExchangeOnline -Confirm:$false
  exit
}}

if (-not $compliant) {{
  try {{ Enable-EOPProtectionPolicyRule -Identity $desiredName | Out-Null }} catch {{ $null = $null }}
  try {{ Enable-ATPProtectionPolicyRule -Identity $desiredName | Out-Null }} catch {{ $null = $null }}

  $after = Get-RuleState $desiredName
  $out = [PSCustomObject]@{{
    mode = "{mode}"
    level = "{level}"
    desired = $desiredName
    before = $state
    after = $after
    availableRules = ($preset | Select-Object Name,State)
    action = "enabled_attempted"
  }}
  $out | ConvertTo-Json -Compress
}} else {{
  $out = [PSCustomObject]@{{
    mode = "{mode}"
    level = "{level}"
    desired = $desiredName
    current = $state
    availableRules = ($preset | Select-Object Name,State)
    action = "already_enabled"
  }}
  $out | ConvertTo-Json -Compress
}}

Disconnect-ExchangeOnline -Confirm:$false
"""

    code, stdout, stderr = _run_powershell(ps_script)

    if code != 0:
        return "ERROR", {"stderr": stderr, "stdout": stdout}

    try:
        result = json.loads(stdout) if stdout else {}
    except Exception:
        return "ERROR", {
            "reason": "Failed to parse PowerShell output (expected JSON)",
            "raw_stdout": stdout,
            "raw_stderr": stderr,
        }

    # If PowerShell couldn't find any matching rules, it exits after writing JSON.
    if result.get("error"):
        # No preset rules exist in this tenant -> not enforceable / not applicable
        return "NOT_EVALUATED", result


    if mode == "report-only":
        return ("COMPLIANT" if result.get("compliant") else "DRIFTED"), result

    if result.get("action") == "enabled_attempted":
        # Could still be drifted if enable didn't actually stick, but this signals we attempted change.
        return "UPDATED", result

    return "COMPLIANT", result
