import os, json
from datetime import datetime, timezone
from engine.constants import ACTION_TO_STATE, ControlState

def write_audit_event(tenant_name: str, event: dict):
    action = event.get("action")
    event.setdefault(
        "state",
        ACTION_TO_STATE.get(action, ControlState.ERROR)
    )

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H-%M-%S")
    path = os.path.join("output", "audit", tenant_name, f"{stamp}_{event['controlId']}.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(event, f, indent=2)
    return path