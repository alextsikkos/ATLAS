CONTROL = {
    "id": "UserRiskPolicy",
    "name": "Require password change for risky users (MFA + password change)",
    "tier": "Tier-2",
    "requires_approval": True,
    "default_mode": "report-only",
    "impact": "medium",
    "secure_score_ids": ["UserRiskPolicy"],
}