from __future__ import annotations

from typing import Any, Dict, List, Tuple

def _safe_import_dnspython():
    try:
        import dns.resolver  # type: ignore
        return dns.resolver
    except Exception:
        return None


def check_dmarc(domain: str) -> Tuple[str, Dict[str, Any]]:
    """
    Checks for _dmarc.<domain> TXT record.

    COMPLIANT: TXT exists and contains v=DMARC1
    DRIFTED: no DMARC TXT record, or doesn't contain v=DMARC1
    ERROR: dnspython not installed / resolver failure
    """
    resolver = _safe_import_dnspython()
    if resolver is None:
        return "ERROR", {
            "reason": "dnspython not installed (pip install dnspython)",
            "domain": domain,
            "record": f"_dmarc.{domain}",
        }

    qname = f"_dmarc.{domain}".strip(".")
    try:
        answers = resolver.resolve(qname, "TXT")
        txt_values: List[str] = []
        for rdata in answers:
            # rdata.strings may be bytes chunks; prefer str(rdata)
            txt = str(rdata).strip('"')
            txt_values.append(txt)

        joined = " ".join(txt_values)
        ok = "V=DMARC1" in joined.upper()

        if ok:
            return "COMPLIANT", {
                "domain": domain,
                "record": qname,
                "txt": txt_values[:5],
            }

        return "DRIFTED", {
            "domain": domain,
            "record": qname,
            "txt": txt_values[:5],
            "reason": "DMARC record missing v=DMARC1",
        }

    except Exception as e:
        return "DRIFTED", {
            "domain": domain,
            "record": qname,
            "reason": "No DMARC TXT record found",
            "error": str(e),
        }
