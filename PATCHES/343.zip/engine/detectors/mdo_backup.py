import json
import subprocess
from pathlib import Path
from typing import Tuple, Dict, Any


def _is_true(v) -> bool:
    return str(v).strip().lower() == "true"


def _run_exo_ps(script_name: str, tenant: dict, timeout_s: int = 240) -> Tuple[bool, Dict[str, Any]]:
    """
    Runs an EXO PowerShell detector script and returns:
      (ok, payload)

    ok=False payload includes stderr/stdout and reason.
    ok=True  payload is parsed JSON from stdout.
    """
    tenant_domain = tenant.get("tenant_domain")
    if not tenant_domain:
        return False, {"reason": "tenant_domain missing from tenant config (e.g. contoso.onmicrosoft.com)"}

    exo = tenant.get("exo", {}) or {}
    app_id = exo.get("appId", "") or ""
    thumb = exo.get("certThumbprint", "") or ""

    ps_script = Path("engine") / "detectors" / script_name
    if not ps_script.exists():
        return False, {"reason": f"Missing PowerShell script: {ps_script}"}

    cmd = [
        "powershell",
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(ps_script),
        "-TenantDomain",
        tenant_domain,
    ]

    # App-only cert auth (required for prod). If values are present, use them.
    if app_id and thumb:
        cmd += ["-AppId", app_id, "-CertThumbprint", thumb]

    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)

    if proc.returncode != 0:
        return False, {
            "reason": "EXO PowerShell call failed",
            "stderr": (proc.stderr or "").strip(),
            "stdout": (proc.stdout or "").strip(),
            "exitCode": proc.returncode,
            "script": script_name,
        }

    try:
        data = json.loads(proc.stdout or "{}")
    except Exception as e:
        return False, {
            "reason": "Failed to parse EXO PowerShell JSON output",
            "error": str(e),
            "stdout": (proc.stdout or "").strip(),
            "script": script_name,
        }

    return True, data
def _as_list(x):
    """
    EXO PowerShell JSON can return:
      - [] (no results)
      - {} (single object)
      - [ {}, {} ] (array)
    Normalize to a list of dicts.
    """
    if x is None:
        return []
    if isinstance(x, list):
        return x
    if isinstance(x, dict):
        return [x]
    # unexpected (e.g. string) — return empty but keep raw for debugging upstream if needed
    return []


def detect_safe_links_status(tenant: dict) -> Tuple[str, Dict[str, Any]]:
    """
    Real detector using EXO PowerShell via engine/detectors/exo_safe_links.ps1

    Exists-anywhere logic (final):
      COMPLIANT if any active Safe Links policy exists
      DRIFTED only if no Safe Links policy exists at all
    """
    ok, data = _run_exo_ps("exo_safe_links.ps1", tenant)
    if not ok:
        return "ERROR", data

    policies = _as_list(data.get("policies"))
    rules = _as_list(data.get("rules"))

    active_policies = [
        p for p in policies
        if _is_true(p.get("EnableSafeLinksForEmail"))
        or _is_true(p.get("EnableSafeLinksForOffice"))
        or _is_true(p.get("EnableSafeLinksForTeams"))
    ]

    if active_policies:
        return "COMPLIANT", {
            "policyCount": len(policies),
            "activePolicyCount": len(active_policies),
            "ruleCount": len(rules),
            "activePolicies": [p.get("Name") for p in active_policies if p.get("Name")][:10],
            "note": "Safe Links active via policy (rules not required for built-in protection)",
        }

    return "DRIFTED", {
        "policyCount": len(policies),
        "activePolicyCount": 0,
        "ruleCount": len(rules),
        "reason": "No Safe Links policy found",
    }


def detect_safe_attachments_status(tenant: dict) -> Tuple[str, Dict[str, Any]]:
    """
    Real detector using EXO PowerShell via engine/detectors/exo_safe_attachments.ps1

    Exists-anywhere logic:
      COMPLIANT if any Safe Attachments policy exists
      DRIFTED only if no policy exists at all
    """
    ok, data = _run_exo_ps("exo_safe_attachments.ps1", tenant)
    if not ok:
        return "ERROR", data

    policies = _as_list(data.get("policies"))
    rules = _as_list(data.get("rules"))


    if len(policies) > 0:
        return "COMPLIANT", {
            "policyCount": len(policies),
            "ruleCount": len(rules),
            "policies": [p.get("Name") for p in policies if p.get("Name")][:10],
            "note": "Safe Attachments detected via policy existence (rules not required for built-in protection)",
        }

    return "DRIFTED", {
        "policyCount": 0,
        "ruleCount": len(rules),
        "reason": "No Safe Attachments policy found",
    }


def detect_anti_phish_status(tenant: dict) -> Tuple[str, Dict[str, Any]]:
    """
    Real detector using EXO PowerShell via engine/detectors/exo_anti_phish.ps1

    Exists-anywhere logic:
      COMPLIANT if any Anti-Phish policy exists
      DRIFTED only if no policy exists at all
    """
    ok, data = _run_exo_ps("exo_anti_phish.ps1", tenant)
    if not ok:
        return "ERROR", data

    policies = _as_list(data.get("policies"))
    rules = _as_list(data.get("rules"))


    if len(policies) > 0:
        return "COMPLIANT", {
            "policyCount": len(policies),
            "ruleCount": len(rules),
            "policies": [p.get("Name") for p in policies if p.get("Name")][:10],
            "note": "Anti-Phish detected via policy existence (rules not required for built-in protection)",
        }

    return "DRIFTED", {
        "policyCount": 0,
        "ruleCount": len(rules),
        "reason": "No Anti-Phish policy found",
    }
def detect_anti_spam_status(tenant: dict):
    """
    Defender for Office 365 – Anti-Spam (Hosted Content Filter)

    Exists-anywhere logic:
      COMPLIANT if any policy exists
      DRIFTED only if none exist
    """
    ok, data = _run_exo_ps("exo_anti_spam.ps1", tenant)
    if not ok:
        return "ERROR", data

    policies = _as_list(data.get("policies"))
    rules = _as_list(data.get("rules"))


    if policies:
        return "COMPLIANT", {
            "policyCount": len(policies),
            "ruleCount": len(rules),
            "policies": [p.get("Name") for p in policies][:10],
            "note": "Anti-spam policy detected (Hosted Content Filter)",
        }

    return "DRIFTED", {
        "policyCount": 0,
        "ruleCount": len(rules),
        "reason": "No anti-spam (Hosted Content Filter) policy found",
    }
def detect_anti_malware_status(tenant: dict):
    """
    Defender for Office 365 – Anti-Malware

    Exists-anywhere logic:
      COMPLIANT if any policy exists
      DRIFTED only if none exist
    """
    ok, data = _run_exo_ps("exo_anti_malware.ps1", tenant)
    if not ok:
        return "ERROR", data

    policies = _as_list(data.get("policies"))
    rules = _as_list(data.get("rules"))


    if policies:
        return "COMPLIANT", {
            "policyCount": len(policies),
            "ruleCount": len(rules),
            "policies": [p.get("Name") for p in policies][:10],
            "note": "Anti-malware policy detected",
        }

    return "DRIFTED", {
        "policyCount": 0,
        "ruleCount": len(rules),
        "reason": "No anti-malware policy found",
    }
def detect_preset_security_policies_status(tenant: dict):
    """
    Preset Security Policies (Standard/Strict/Built-in) detection.

    COMPLIANT if:
      - Strict is Enabled in BOTH EOP + ATP rules, OR
      - Standard is Enabled in BOTH EOP + ATP rules
    DRIFTED if neither Standard nor Strict is enabled across both rule types.

    Notes:
    - Built-in is informational; many tenants have it regardless.
    - We check both EOP and ATP rules because orgs with MDO typically enable both.
    """
    ok, data = _run_exo_ps("exo_preset_security_policies.ps1", tenant)
    if not ok:
        return "ERROR", data

    eop_rules = _as_list(data.get("eopRules"))
    atp_rules = _as_list(data.get("atpRules"))

    def _state_for(name: str, rules: list[dict]) -> str | None:
        for r in rules:
            if (r.get("Name") or "").strip().lower() == name.strip().lower():
                return r.get("State")
        return None

    # These are the canonical rule names used by the cmdlets docs/examples
    standard_name = "Standard Preset Security Policy"
    strict_name = "Strict Preset Security Policy"
    builtin_name = "Built-in protection preset security policy"

    eop_standard = _state_for(standard_name, eop_rules)
    eop_strict = _state_for(strict_name, eop_rules)
    eop_builtin = _state_for(builtin_name, eop_rules)

    atp_standard = _state_for(standard_name, atp_rules)
    atp_strict = _state_for(strict_name, atp_rules)
    atp_builtin = _state_for(builtin_name, atp_rules)

    strict_enabled = (eop_strict == "Enabled") and (atp_strict == "Enabled")
    standard_enabled = (eop_standard == "Enabled") and (atp_standard == "Enabled")

    details = {
        "eop": {"standard": eop_standard, "strict": eop_strict, "builtin": eop_builtin},
        "atp": {"standard": atp_standard, "strict": atp_strict, "builtin": atp_builtin},
        "note": "Preset security policies are represented by EOP/ATP protection policy rules in EXO PowerShell.",
    }

    if strict_enabled:
        details["winner"] = "strict"
        return "COMPLIANT", details

    if standard_enabled:
        details["winner"] = "standard"
        return "COMPLIANT", details

    details["winner"] = None
    details["reason"] = "Neither Standard nor Strict preset security policy is enabled (EOP+ATP)."
    return "DRIFTED", details
def detect_dkim_enabled_all_domains_status(tenant: dict):
    """
    Exchange Online DKIM enabled for all custom domains (non-onmicrosoft).

    COMPLIANT: all custom domains have DKIM Enabled=True
    DRIFTED: one or more custom domains not enabled / missing config
    NOT_EVALUATED: no custom domains found
    """
    ok, data = _run_exo_ps("exo_dkim.ps1", tenant)
    if not ok:
        return "ERROR", data

    custom = _as_list(data.get("customDomains"))
    dkim = _as_list(data.get("dkim"))

    # customDomains comes back as list of strings; normalize
    custom_domains = [d for d in custom if isinstance(d, str)]

    if not custom_domains:
        return "NOT_EVALUATED", {"reason": "No custom (non-onmicrosoft) accepted domains found"}

    # dkim entries are dicts
    not_enabled = []
    enabled = []

    for entry in dkim:
        if not isinstance(entry, dict):
            continue
        domain = entry.get("Domain")
        is_enabled = bool(entry.get("Enabled"))
        if is_enabled:
            enabled.append(domain)
        else:
            not_enabled.append(domain)

    details = {
        "customDomainCount": len(custom_domains),
        "enabledCount": len([d for d in enabled if d]),
        "notEnabledCount": len([d for d in not_enabled if d]),
        "notEnabledDomains": [d for d in not_enabled if d],
    }

    if not_enabled:
        details["reason"] = "DKIM is not enabled for one or more custom domains"
        return "DRIFTED", details

    return "COMPLIANT", details
def detect_dmarc_all_domains_status(tenant: dict):
    """
    DMARC record exists for all custom accepted domains.

    COMPLIANT: all custom domains have v=DMARC1
    DRIFTED: one or more missing
    NOT_EVALUATED: no custom domains
    ERROR: dnspython missing
    """
    ok, data = _run_exo_ps("exo_dkim.ps1", tenant)  # reuse accepted domain list
    if not ok:
        return "ERROR", data

    custom = _as_list(data.get("customDomains"))
    custom_domains = [d for d in custom if isinstance(d, str)]

    if not custom_domains:
        return "NOT_EVALUATED", {"reason": "No custom (non-onmicrosoft) accepted domains found"}

    from engine.detectors.dns import check_dmarc

    results = []
    missing = []
    errors = []

    for d in custom_domains:
        st, det = check_dmarc(d)
        results.append({"domain": d, "state": st, "details": det})
        if st == "DRIFTED":
            missing.append(d)
        elif st == "ERROR":
            errors.append(d)

    if errors:
        return "ERROR", {
            "reason": "One or more DMARC checks failed",
            "errorDomains": errors,
            "results": results,
        }

    if missing:
        return "DRIFTED", {
            "reason": "DMARC missing on one or more custom domains",
            "missingDomains": missing,
            "results": results,
        }

    return "COMPLIANT", {
        "customDomainCount": len(custom_domains),
        "results": results,
    }
