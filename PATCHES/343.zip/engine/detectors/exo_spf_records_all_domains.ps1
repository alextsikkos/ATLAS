param(
    [Parameter(Mandatory=$true)]
    [string]$TenantDomain,
    [string]$AppId,
    [string]$CertThumbprint
)

$ErrorActionPreference = "Stop"
Import-Module ExchangeOnlineManagement

if ($AppId -and $CertThumbprint) {
    Connect-ExchangeOnline -AppId $AppId -CertificateThumbprint $CertThumbprint -Organization $TenantDomain -ShowBanner:$false -ErrorAction Stop | Out-Null
}
else {
    Connect-ExchangeOnline -Organization $TenantDomain -ShowBanner:$false -ErrorAction Stop | Out-Null
}

function Get-SpfTxt($domain) {
    try {
        $txt = Resolve-DnsName -Name $domain -Type TXT -ErrorAction Stop
        $strings = @($txt | Where-Object { $_.Strings } | ForEach-Object { $_.Strings })
        return @($strings)
    } catch {
        return $null
    }
}

try {
    $errors = @{}
    $cmdletsUsed = @()

    $cmdletsUsed += "Get-AcceptedDomain"
    $domains = $null
    try { $domains = Get-AcceptedDomain -ErrorAction Stop } catch { $errors["Get-AcceptedDomain"] = $_.Exception.Message }

    $customDomains = @()
    if ($domains) {
        $customDomains = @($domains | Where-Object { $_.DomainName } | ForEach-Object { "$($_.DomainName)" })
    }

    $checked = @()
    $missing = @()

    foreach ($d in $customDomains) {
        $txts = Get-SpfTxt $d
        if ($txts -eq $null) {
            $missing += $d
        } else {
            $hasSpf = $false
            foreach ($t in $txts) { if ($t -match "v=spf1") { $hasSpf = $true } }
            if (-not $hasSpf) { $missing += $d }
            $checked += @{ domain=$d; txtCount=@($txts).Count; hasSpf=$hasSpf }
        }
    }

    @{
        connected = $true
        cmdletsUsed = $cmdletsUsed
        domainCount = @($customDomains).Count
        checkedSamples = @($checked | Select-Object -First 10)
        missingSpfCount = @($missing).Count
        missingSpfDomains = @($missing | Select-Object -First 25)
        errors = $errors
    } | ConvertTo-Json -Depth 10
}
catch {
    @{
        connected = $false
        error = $_.Exception.Message
    } | ConvertTo-Json -Depth 6
}

finally {
    try { Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue | Out-Null } catch {}
}
