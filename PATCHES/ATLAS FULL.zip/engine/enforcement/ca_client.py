import requests

BASE = "https://graph.microsoft.com/v1.0"

def list_policies(headers: dict, top: int = 50):
    r = requests.get(f"{BASE}/identity/conditionalAccess/policies?$top={top}", headers=headers, timeout=30)
    r.raise_for_status()
    return r.json().get("value", [])

def find_policy_by_name(headers: dict, display_name: str):
    r = requests.get(
        f"{BASE}/identity/conditionalAccess/policies",
        headers=headers,
        params={"$filter": f"displayName eq '{display_name}'", "$top": "1"},
        timeout=30
    )
    r.raise_for_status()
    vals = r.json().get("value", [])
    return vals[0] if vals else None

def create_policy(headers: dict, payload: dict):
    import requests

    r = requests.post(
        f"{BASE}/identity/conditionalAccess/policies",
        headers=headers,
        json=payload,
        timeout=30
    )

    # Always try to capture useful error info (Graph often returns JSON error bodies)
    try:
        body = r.json() if r.content else None
    except Exception:
        body = None

    return r.status_code, body, (r.text or "")


def patch_policy(headers: dict, policy_id: str, payload: dict):
    import requests

    r = requests.patch(
        f"{BASE}/identity/conditionalAccess/policies/{policy_id}",
        headers=headers,
        json=payload,
        timeout=30
    )

    try:
        body = r.json() if r.content else None
    except Exception:
        body = None

    return r.status_code, body, (r.text or "")
