param(
  [Parameter(Mandatory=$true)]
  [string]$AdminUrl,

  [Parameter(Mandatory=$true)]
  [string]$Enabled,

  [string]$AccountId,
  [string]$ClientId,
  [string]$TenantId,
  [string]$CertificateThumbprint,
  [string]$CertificatePath,
  [string]$CertificatePassword
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Online.SharePoint.PowerShell -ErrorAction SilentlyContinue | Out-Null
# Connect to SPO admin
if ($ClientId -and $TenantId -and (($CertificateThumbprint -and $CertificateThumbprint.Trim().Length -gt 0) -or ($CertificatePath -and $CertificatePath.Trim().Length -gt 0))) {

  if ($CertificateThumbprint -and $CertificateThumbprint.Trim().Length -gt 0) {
    Connect-SPOService -Url $AdminUrl -ClientId $ClientId -Tenant $TenantId -CertificateThumbprint $CertificateThumbprint -ErrorAction Stop
  }
  elseif ($CertificatePath -and $CertificatePath.Trim().Length -gt 0) {
    if ($CertificatePassword -and $CertificatePassword.Trim().Length -gt 0) {
      $sec = ConvertTo-SecureString -String $CertificatePassword -AsPlainText -Force
      Connect-SPOService -Url $AdminUrl -ClientId $ClientId -Tenant $TenantId -CertificatePath $CertificatePath -CertificatePassword $sec -ErrorAction Stop
    }
    else {
      Connect-SPOService -Url $AdminUrl -ClientId $ClientId -Tenant $TenantId -CertificatePath $CertificatePath -ErrorAction Stop
    }
  }

}
else {
  if ($AccountId -and $AccountId.Trim().Length -gt 0) {
    try {
      Connect-SPOService -Url $AdminUrl -AccountId $AccountId -ErrorAction Stop
    } catch {
      Connect-SPOService -Url $AdminUrl -ErrorAction Stop
    }
  }
  else {
    Connect-SPOService -Url $AdminUrl -ErrorAction Stop
  }
}


if ($Enabled -eq '$true') {
  Set-SPOTenant -PreventExternalUsersFromResharing $true
} else {
  Set-SPOTenant -PreventExternalUsersFromResharing $false
}

Write-Output "OK"
exit 0
